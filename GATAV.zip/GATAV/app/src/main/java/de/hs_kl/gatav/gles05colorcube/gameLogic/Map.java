package de.hs_kl.gatav.gles05colorcube.gameLogic;
import android.graphics.Bitmap;
import android.graphics.Color;

public class Map {
    private enum MapObjectType {
        EMPTY,
        START,
        DEATH,
        GOAL
    }
    private MapObjectType[][] mapMap;

    public Map(Bitmap map) {
        int height = map.getHeight();
        int width = map.getWidth();
        mapMap = new MapObjectType[height][width];

        for (int y = 0; y < mapMap.length; y++) {
            MapObjectType[] row = mapMap[y];

            for (int x = 0; x <  row.length; x++) {
                MapObjectType e = row[x];
                Color col = map.getColor(x, y);

                if (col.red() > 200) {

                }
            }
        }
    }
}
