package de.hs_kl.gatav.gles05colorcube.gameLogic;
import android.graphics.BitmapFactory;

public class MapLoader {
    public Map load(String path) {
        return new Map(BitmapFactory.decodeFile(path));
    }
}
